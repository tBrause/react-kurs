module.exports = {
  singleQuote: true,
  useTabs: true,
};
