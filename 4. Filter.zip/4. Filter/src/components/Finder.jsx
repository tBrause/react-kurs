export default function Finder() {
	return <div>Finder</div>;
}
