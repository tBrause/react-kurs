export default function MoodDisplay() {
	const moods = ['😡', '🙁', '😐', '🙂', '🥳'];

	return (
		<div className="mood">
			<div className="mood__image" role="img" aria-label="Stimmungsanzeige">
				😐
			</div>
			<div className="mood__buttons">
				<button>Schlechter</button>
				<button>Besser</button>
				<button>Zurücksetzen</button>
			</div>
		</div>
	);
}

/* 

Schafft einen State moodIndex, der den Array-Index enhält, der für die Ausgabe
des Emojis verwendet wird. Startwert soll 2 sein.
Schreibt dann drei kleine Hilfsfunktionen increment, decrement und reset,
wobei reset den Index auf den Startwert setzen soll, und die beiden anderen Funktionen
den Wert nur bis zum Maximal- bzw. Minimalwert verändern sollen.
Bonus: Die Schlechter und Besser-Buttons sollen disabled sein, wenn das
jeweilige Limit erreicht ist. 

Der nächste Schritt wäre dann die Abstraktion in einen eigenen useCount-Hook.
Der Hook soll Startwert, Minimalwert, Maximalwert und Schrittgröße (mit
default 1) erhalten. Der Hook soll ein Objekt mit den Werten bzw. Funktionen count,
increment, decrement, setCount, reset, isMax und isMin zurückgeben.

*/
