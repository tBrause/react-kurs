import Product from './Product';

export default function ProductsList({ products }) {
	return (
		<section className="products">
			{products.map((product) => (
				<Product {...product} key={product.id} />
			))}
		</section>
	);
}

/*
 Stellt innerhalb von .products für jedes Produkt ein Product-Komponente dar
 */
