import React from 'react';
import ReactDOM from 'react-dom/client';
import EffectDemo from './components/EffectDemo';

import Finder from './components/Finder';

import VideoPlayer from './components/VideoPlayer';

ReactDOM.createRoot(document.getElementById('root')).render(
	<React.StrictMode>
		<Finder />
	</React.StrictMode>
);
