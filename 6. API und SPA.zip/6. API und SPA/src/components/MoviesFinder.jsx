import SearchPage from './SearchPage';

export default function MoviesFinder() {
	return (
		<div className="movies-finder">
			<SearchPage />
		</div>
	);
}
