export default function MovieTeasers({ movies }) {
	return <div className="movie-teasers"></div>;
}
